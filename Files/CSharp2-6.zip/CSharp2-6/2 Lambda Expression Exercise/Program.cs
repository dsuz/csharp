﻿using System;
using System.Collections.Generic;
using System.Linq;

class Program
{
    static void Main(string[] args)
    {
        int[] intArray = { 9, 3, 5, 8, 1, 7, 2, 4, 6, 0 };
        string[] stringArray = { "banana", "orange", "kiwi", "apple", "pineapple" };

        // 課題 1 Linq を使って、stringArray から「文字列の長さが 5 文字より長い要素」を抽出し、出力せよ
        // 課題 2 Linq を使って、intArray から偶数を抽出し、出力せよ
    }
}

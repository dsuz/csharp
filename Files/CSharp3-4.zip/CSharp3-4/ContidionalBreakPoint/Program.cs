﻿using System;

class Program
{
    static void Main(string[] args)
    {
        Console.Write("Input: ");
        string buf = Console.ReadLine();
        Console.WriteLine(buf);
        Console.WriteLine("Hit Enter...");
        Console.ReadLine();
    }
}
